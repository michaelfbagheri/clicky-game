import React from "react";
import "./style.css";

const DataDivs = () => (
    <div className="box-1">test</div>

);

export default DataDivs;


